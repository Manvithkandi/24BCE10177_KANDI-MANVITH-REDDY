<?php
// loading the mongoDB library
require 'vendor/autoload.php';

try {
    // Connecting to local MongoDB server
    $client = new MongoDB\Client("mongodb://localhost:27017");
    
    // Create and Select the database named 'fleet_engine'
    $db = $client->fleet_engine;
    
    echo "SUCCESS: Connected to MongoDB Fleet Engine Database!\n";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
?>
<?php
// Load the MongoDB library you just installed
require 'vendor/autoload.php';

try {
    // Connect to your local MongoDB server
    $client = new MongoDB\Client("mongodb://localhost:27017");
    
    // Create/Select the database named 'fleet_engine'
    $db = $client->fleet_engine;
    
    echo "SUCCESS: Connected to MongoDB Fleet Engine Database!\n";
    
} catch (Exception $e) {
    echo "ERROR: " . $e->getMessage() . "\n";
}
?>
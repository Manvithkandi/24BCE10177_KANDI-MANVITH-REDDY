<?php
//database connection
require 'vendor/autoload.php';

try {
    $client = new MongoDB\Client("mongodb://localhost:27017");
    $db = $client->fleet_engine;
} catch (Exception $e) {
    echo "ERROR: Could not connect to database.\n";
    exit;
}

if ($argc < 2) {
    echo "ERROR: Please provide an action. Example: php cli.php dispatch DRV_001 TRK_001 SHP_001 WH_001\n";
    exit;
}

$action = $argv[1];

switch ($action) {
    
    case 'dispatch':
        if ($argc < 6) {
            echo "ERROR: Missing parameters.\nUsage: php cli.php dispatch <driver_id> <vehicle_id> <shipment_id> <warehouse_id>\n";
            exit;
        }

        $driverId = $argv[2];
        $vehicleId = $argv[3];
        $shipmentId = $argv[4];
        $warehouseId = $argv[5]; 

        $driversCollection = $db->drivers;
        $vehiclesCollection = $db->vehicles;
        $shipmentsCollection = $db->shipments;
        $warehousesCollection = $db->warehouses;
        $dispatchLogs = $db->dispatch_logs; 

        /* --- check DRIVER --- */
        $driver = $driversCollection->findOne(['_id' => $driverId]);
        if (!$driver) { echo "ERROR: Driver $driverId does not exist.\n"; exit; }
        
        $allowedDriverStatuses = ['working', 'active', 'available']; 
        if (!in_array(strtolower($driver['status'] ?? ''), $allowedDriverStatuses)) {
            echo "ERROR: Dispatch Blocked. Driver $driverId is marked as '" . ($driver['status'] ?? 'unknown') . "'.\n"; exit;
        }

        /* ---check VEHICLE--- */
        $vehicle = $vehiclesCollection->findOne(['_id' => $vehicleId]);
        if (!$vehicle) { echo "ERROR: Vehicle $vehicleId does not exist.\n"; exit; }
        
        $blockedVehicleStatuses = ['in transit', 'in-transit', 'maintenance', 'scrapped', 'sold'];
        if (in_array(strtolower($vehicle['status'] ?? ''), $blockedVehicleStatuses)) {
            echo "ERROR: Dispatch Blocked. Truck $vehicleId is " . ($vehicle['status'] ?? 'unavailable') . ".\n"; exit;
        }

        /* --- check WAREHOUSE--- */
        $warehouse = $warehousesCollection->findOne(['_id' => $warehouseId]);
        if (!$warehouse) { echo "ERROR: Destination Warehouse $warehouseId does not exist.\n"; exit; }
        
        $currentParkedCount = count($warehouse['parked_vehicles'] ?? []);
        $maxCapacity = $warehouse['capacity'] ?? 0;
        
        if ($currentParkedCount >= $maxCapacity) {
            echo "ERROR: Dispatch Blocked. Destination $warehouseId is at maximum capacity ($maxCapacity/$maxCapacity).\n"; exit;
        }

        /* ---IDEMPOTENCY --- */
        $fiveMinutesAgo = date("Y-m-d H:i:s", strtotime('-5 minutes'));
        $duplicateCheck = $dispatchLogs->findOne([
            'driver_id' => $driverId, 
            'vehicle_id' => $vehicleId, 
            'shipment_id' => $shipmentId,
            'timestamp' => ['$gte' => $fiveMinutesAgo]
        ]);

        if ($duplicateCheck) {
            echo "SUCCESS: Dispatch already recorded recently. Skipping duplicate.\n"; exit;
        }

        /* --- EXECUTION --- */
        try {
            $dispatchLogs->insertOne([
                "driver_id" => $driverId, 
                "vehicle_id" => $vehicleId, 
                "shipment_id" => $shipmentId,
                "destination_warehouse" => $warehouseId, 
                "action" => "dispatched", 
                "timestamp" => date("Y-m-d H:i:s")
            ]);

            $vehiclesCollection->updateOne(['_id' => $vehicleId], ['$set' => ['status' => 'In-Transit']]);
            $shipmentsCollection->updateOne(['_id' => $shipmentId], ['$set' => [
                'status' => 'In-Transit', 
                'assigned_driver' => $driverId, 
                'assigned_vehicle' => $vehicleId, 
                'destination_warehouse' => $warehouseId
            ]]);

            echo "SUCCESS: Driver $driverId is moving Shipment $shipmentId to $warehouseId via Truck $vehicleId!\n";
        } catch (Exception $e) {
            echo "FAILED to process dispatch: " . $e->getMessage() . "\n";
        }
        break;

    default:
        echo "ERROR: Unknown action.\n";
        break;
}
?>
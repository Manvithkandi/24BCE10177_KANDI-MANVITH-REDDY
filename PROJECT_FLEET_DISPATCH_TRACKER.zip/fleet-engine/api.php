<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE");

require 'vendor/autoload.php';

try {
    $client = new MongoDB\Client("mongodb://localhost:27017");
    
    $collectionName = $_GET['collection'] ?? 'vehicles';
    $collection = $client->fleet_engine->$collectionName;

    $idField = 'vehicle_id'; 
    if ($collectionName === 'warehouses') $idField = 'warehouse_id';
    if ($collectionName === 'shipments') $idField = 'shipment_id';
    if ($collectionName === 'drivers') $idField = 'driver_id';

    $requestMethod = $_SERVER['REQUEST_METHOD'];

    if ($requestMethod === 'POST') {
        /* --- CREATE --- */
        $jsonPayload = file_get_contents('php://input');
        $data = json_decode($jsonPayload, true);

        if (!$data || !isset($data[$idField])) {
            http_response_code(400); 
            echo json_encode(["error" => "Invalid data. '$idField' required."]); 
            exit;
        }

        if ($collection->findOne(['_id' => $data[$idField]])) {
            http_response_code(409); 
            echo json_encode([
                "status" => "error",
                "error" => "Insertion blocked. A record in the '$collectionName' collection with $idField '" . $data[$idField] . "' already exists."
            ]); 
            exit;
        }

        $data['_id'] = $data[$idField]; 
        $insertResult = $collection->insertOne($data);
        
        echo json_encode(["status" => "success", "action" => "inserted", "primary_key" => $data['_id']]);

    } elseif ($requestMethod === 'GET') {
        /* --- READ (Filters out Soft-Deleted items by default) --- */
        $cursor = $collection->find(['status' => ['$nin' => ['Scrapped', 'Retired', 'Deleted', 'Cancelled']]]);
        $results = [];
        foreach ($cursor as $document) { $results[] = $document; }

        echo json_encode(["status" => "success", "total_active" => count($results), "data" => $results]);

    } elseif ($requestMethod === 'PUT') {
        /* --- UPDATE (With Capacity Logic) --- */
        $jsonPayload = file_get_contents('php://input');
        $data = json_decode($jsonPayload, true);

        if (!$data || !isset($data[$idField])) {
            http_response_code(400); 
            echo json_encode(["error" => "'$idField' required to update."]); 
            exit;
        }

        $recordId = $data[$idField];
        unset($data[$idField]); 
        unset($data['_id']); // Never allow primary key updates

        if (isset($data['park_vehicle']) && $collectionName === 'warehouses') {
            // EDGE CASE CHECK: Is the warehouse full?
            $warehouse = $collection->findOne(['_id' => $recordId]);
            $currentParked = count($warehouse['parked_vehicles'] ?? []);
            $maxCapacity = $warehouse['capacity'] ?? 0;

            if ($currentParked >= $maxCapacity) {
                http_response_code(409);
                echo json_encode(["error" => "Warehouse is full ($maxCapacity/$maxCapacity). Cannot park " . $data['park_vehicle']]);
                exit;
            }

            $updateResult = $collection->updateOne(
                ['_id' => $recordId],
                ['$addToSet' => ['parked_vehicles' => $data['park_vehicle']]]
            );
        } else {
            // Standard update
            $updateResult = $collection->updateOne(['_id' => $recordId], ['$set' => $data]);
            
            // EDGE CASE CHECK: If a truck is updated to "Scrapped" via PUT, cascade remove it
            if ($collectionName === 'vehicles' && isset($data['status']) && strtolower($data['status']) === 'scrapped') {
                $client->fleet_engine->warehouses->updateMany(
                    [], ['$pull' => ['parked_vehicles' => $recordId]]
                );
            }
        }

        echo json_encode(["status" => "success", "action" => "updated", "modified_count" => $updateResult->getModifiedCount()]);

    } elseif ($requestMethod === 'DELETE') {
        /* --- SOFT DELETE (Intercept & Archive - Local Standalone Version) --- */
        $jsonPayload = file_get_contents('php://input');
        $data = json_decode($jsonPayload, true) ?? [];
        $recordId = $data[$idField] ?? $_GET[$idField] ?? null;

        if (!$recordId) {
            http_response_code(400); 
            echo json_encode(["error" => "'$idField' required for deletion."]); 
            exit;
        }

        // Determine the soft-delete status based on collection
        $softDeleteStatus = 'Deleted';
        if ($collectionName === 'vehicles') $softDeleteStatus = 'Scrapped';
        if ($collectionName === 'drivers') $softDeleteStatus = 'Retired';
        if ($collectionName === 'shipments') $softDeleteStatus = 'Cancelled';

        // Intercept the delete and convert to a status update
        $deleteResult = $collection->updateOne(
            ['_id' => $recordId], 
            ['$set' => ['status' => $softDeleteStatus]]
        );
        
        $cleanupMessage = "Soft deleted as '$softDeleteStatus'. No array cleanup needed.";

        // Cascading Logic: Yank scrapped vehicles out of warehouse parking lots
        if ($collectionName === 'vehicles') {
            $warehouseCollection = $client->fleet_engine->warehouses;
            $cleanupResult = $warehouseCollection->updateMany(
                [], 
                ['$pull' => ['parked_vehicles' => $recordId]]
            );
            $cleanupMessage = "Status set to Scrapped. Removed from " . $cleanupResult->getModifiedCount() . " warehouse arrays.";
        }

        echo json_encode([
            "status" => "success",
            "action" => "soft_deleted",
            "record_id" => $recordId,
            "cleanup_status" => $cleanupMessage
        ]);

    } else {
        http_response_code(405); 
        echo json_encode(["error" => "Method Not Allowed."]);
    }

} catch (Exception $e) {
    http_response_code(500); 
    echo json_encode(["error" => "Database execution failed.", "details" => $e->getMessage()]);
}
?>
<?php
// Pull in your database connection
require 'vendor/autoload.php';

try {
    $client = new MongoDB\Client("mongodb://localhost:27017");
    $db = $client->fleet_engine;

    echo "Optimizing Fleet Engine Database Architecture...\n\n";

    /* -------------------------------------------------------------------------
       1. THE IDEMPOTENCY COMPOUND INDEX (The most important one)
       Your CLI script searches for 4 things at once: driver, vehicle, shipment, and time.
       A "Compound Index" groups all four into a single high-speed lookup table.
    ------------------------------------------------------------------------- */
    $db->dispatch_logs->createIndex(
        [
            'driver_id' => 1,
            'vehicle_id' => 1,
            'shipment_id' => 1,
            'timestamp' => -1 // -1 sorts by newest first, perfect for time-window checks!
        ],
        ['name' => 'idx_idempotency_fast_lookup']
    );
    echo "[OK] dispatch_logs : High-speed Compound Index created for Idempotency.\n";

    /* -------------------------------------------------------------------------
       2. STATUS INDEXES (For the API and CLI Blocker Checks)
       Your API filters out "Scrapped" trucks and your CLI checks for "Retired" drivers.
       Indexing the 'status' field makes these security checks instant.
    ------------------------------------------------------------------------- */
    $db->vehicles->createIndex(['status' => 1], ['name' => 'idx_vehicle_status']);
    echo "[OK] vehicles      : Status Index created.\n";

    $db->drivers->createIndex(['status' => 1], ['name' => 'idx_driver_status']);
    echo "[OK] drivers       : Status Index created.\n";

    $db->shipments->createIndex(['status' => 1], ['name' => 'idx_shipment_status']);
    echo "[OK] shipments     : Status Index created.\n";

    /* -------------------------------------------------------------------------
       Note on Primary Keys:
       Because we successfully hijacked the _id field in the API to use your custom 
       IDs (like TRK_55), MongoDB already indexed them natively! No extra work needed.
    ------------------------------------------------------------------------- */

    echo "\nSUCCESS: Database Optimization Complete! All queries will now execute in milliseconds.\n";

} catch (Exception $e) {
    echo "FAILED to create indexes: " . $e->getMessage() . "\n";
}
?>
<?php
require 'vendor/autoload.php';

try {
    $client = new MongoDB\Client("mongodb://localhost:27017");
    $db = $client->fleet_engine;

    echo "Starting Database Wipe & Seed Operation...\n\n";

    // 1. WIPE OLD DATA (Start with a clean slate)
    $collections = ['drivers', 'vehicles', 'warehouses', 'shipments', 'dispatch_logs'];
    foreach ($collections as $col) {
        $db->$col->drop();
        echo "[-] Dropped collection: $col\n";
    }
    echo "\n";

    // 2. SEED DRIVERS (DRV_001 to DRV_010)
    $drivers = [];
    for ($i = 1; $i <= 10; $i++) {
        $id = "DRV_" . str_pad($i, 3, "0", STR_PAD_LEFT);
        $status = ($i % 4 == 0) ? "on-leave" : "working"; // Every 4th driver is on leave
        
        $drivers[] = [
            "_id" => $id,
            "driver_id" => $id,
            "name" => "Test Driver $i",
            "license_type" => "Heavy Commercial",
            "status" => $status
        ];
    }
    $db->drivers->insertMany($drivers);
    echo "[+] Seeded 10 Drivers.\n";

    // 3. SEED VEHICLES (TRK_001 to TRK_010)
    $vehicles = [];
    for ($i = 1; $i <= 10; $i++) {
        $id = "TRK_" . str_pad($i, 3, "0", STR_PAD_LEFT);
        $status = ($i % 5 == 0) ? "Maintenance" : "Active"; // Every 5th truck is in maintenance
        
        $vehicles[] = [
            "_id" => $id,
            "vehicle_id" => $id,
            "status" => $status,
            "Registration_Details" => [
                "capacity" => ($i * 2000) . "kg",
                "fuel_type" => ($i % 2 == 0) ? "Diesel" : "Electric",
                "license_plate" => "MP-04-AB-10" . str_pad($i, 2, "0", STR_PAD_LEFT)
            ]
        ];
    }
    $db->vehicles->insertMany($vehicles);
    echo "[+] Seeded 10 Vehicles.\n";

    // 4. SEED WAREHOUSES (WH_001 to WH_010)
    $warehouses = [];
    for ($i = 1; $i <= 10; $i++) {
        $id = "WH_" . str_pad($i, 3, "0", STR_PAD_LEFT);
        
        $warehouses[] = [
            "_id" => $id,
            "warehouse_id" => $id,
            "location" => "Hub Zone $i",
            "capacity" => rand(2, 50), // Random capacity between 2 and 50
            "parked_vehicles" => []    // Starting completely empty
        ];
    }
    $db->warehouses->insertMany($warehouses);
    echo "[+] Seeded 10 Warehouses.\n";

    // 5. SEED SHIPMENTS (SHP_001 to SHP_010)
    $shipments = [];
    for ($i = 1; $i <= 10; $i++) {
        $id = "SHP_" . str_pad($i, 3, "0", STR_PAD_LEFT);
        
        $shipments[] = [
            "_id" => $id,
            "shipment_id" => $id,
            "weight" => rand(100, 5000) . "kg",
            "destination" => "City Sector $i",
            "status" => "Pending",
            "assigned_driver" => null,
            "assigned_vehicle" => null,
            "destination_warehouse" => null
        ];
    }
    $db->shipments->insertMany($shipments);
    echo "[+] Seeded 10 Shipments.\n";

    // Note: We leave dispatch_logs completely empty because no actions have occurred yet!

    echo "\nSUCCESS: Database successfully seeded with 40 records!\n";

} catch (Exception $e) {
    echo "FAILED to seed database: " . $e->getMessage() . "\n";
}
?>
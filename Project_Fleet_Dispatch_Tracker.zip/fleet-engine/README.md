\# Defending the Data Layer: A Fault-Tolerant NoSQL Fleet Management API



\*\*Author:\*\* Kandi Manvith Reddy  

\*\*Institution:\*\* VIT Bhopal University  

\*\*Program:\*\* B.Tech Computer Science and Engineering  



This is a custom CRUD API and CLI dispatch engine built entirely with PHP and MongoDB. By bypassing traditional relational SQL engines, this architecture uses dynamic document structures to enforce strict data integrity, real-time physical capacity constraints, and transactional safety directly at the application layer.



\## Core Features

\* \*\*Smart Primary Keys:\*\* Native duplication interceptor that hijacks standard MongoDB ObjectIDs with custom alphanumeric IDs.

\* \*\*5-Minute Idempotency Lock:\*\* Uses compound B-Tree indexing to catch and block accidental double-submissions (e.g., dispatching the same truck twice).

\* \*\*Cascading Soft-Deletes:\*\* Safely archives decommissioned assets (like retired trucks) to preserve historical logs, while dynamically freeing up physical warehouse parking arrays.

\* \*\*Real-Time State Validation:\*\* CLI engine strictly validates driver availability and warehouse capacity limits before executing multi-collection dispatches.



\## How to Run the Project



\### 1. Prerequisites

\* \*\*PHP 8.x\*\* or higher installed on your machine.

\* \*\*MongoDB Community Server\*\* running locally on default port `27017`.

\* \*(Note: All required PHP dependencies, including the MongoDB driver, are already included in the `vendor` folder for your convenience. You do not need to run `composer install`.)\*



\### 2. Database Initialization

Before running the API, configure your database indexes and seed it with baseline operational data:

First, build the NoSQL B-Tree indexes (Required for the Idempotency Lock):
`php setup_indexes.php`

Next, seed the collections with active trucks and warehouses:
`php seed.php`

### 3. Boot the Local Server

Start the built-in PHP development server by running this command in the project root:
```bash
php -S localhost:8000

## Usage and Testing
### Testing the REST API(via Postman or Browser)
You can test standard CRUD operations by sending GET, POST, PUT, or DELETE requests to the dynamic API router:



http://localhost:8000/api.php?collection=vehicles



http://localhost:8000/api.php?collection=warehouses



http://localhost:8000/api.php?collection=drivers



http://localhost:8000/api.php?collection=shipments

### Running a CLI Dispatch Transaction

To test the business logic, state validation, and idempotency lock, open a new terminal and run a multi-entity dispatch command:
```bash
php cli.php dispatch DRV\_001 TRK\_002 SHP\_003 WH\_001




